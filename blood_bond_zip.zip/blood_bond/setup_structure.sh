#!/bin/bash

echo "Setting up Flutter folder structure..."

# Directories
mkdir -p lib/{core/{config,error,routing,theme,utils,services},shared/{widgets,providers,models},features/{auth/{data,domain/{entities,repositories,usecases},presentation/{screens,widgets,controllers}},profile/{data,domain/{entities,repositories,usecases},presentation/{screens,controllers}},donations/{data,domain/{entities,repositories,usecases},presentation/{screens,controllers}},requests/{data,domain/{entities,repositories,usecases},presentation/{screens,controllers}},inventory/{data,domain/{entities,repositories,usecases},presentation/{screens,controllers}},notifications/{data,domain/{entities,repositories,usecases},presentation/{widgets,controllers}},dashboard/{presentation/{screens,widgets},controllers}},l10n,generated}

# Main files
cat > lib/main.dart << 'EOF'
import 'package:flutter/material.dart';
import 'bootstrap.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await bootstrap();
}
EOF

cat > lib/bootstrap.dart << 'EOF'
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/routing/app_router.dart';
import 'supabase_config.dart';

Future<void> bootstrap() async {
  await SupabaseConfig.init();
  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(appRouterProvider);

    return MaterialApp.router(
      routerConfig: router,
      title: 'Blood Bond',
      theme: AppTheme.lightTheme,
    );
  }
}
EOF

cat > lib/supabase_config.dart << 'EOF'
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class SupabaseConfig {
  static late SupabaseClient client;

  static Future<void> init() async {
    await dotenv.load(fileName: ".env");
    final url = dotenv.env['SUPABASE_URL'] ?? '';
    final anonKey = dotenv.env['SUPABASE_ANON_KEY'] ?? '';

    client = SupabaseClient(url, anonKey);
  }
}
EOF

# Core routing
cat > lib/core/routing/app_router.dart << 'EOF'
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../features/auth/presentation/screens/sign_in_screen.dart';
import '../../features/auth/presentation/screens/auth_gateway_screen.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/',
    routes: [
      GoRoute(path: '/', builder: (_, __) => const AuthGatewayScreen()),
      GoRoute(path: '/signin', builder: (_, __) => const SignInScreen()),
    ],
  );
});
EOF

# Auth controller
cat > lib/features/auth/presentation/controllers/auth_controller.dart << 'EOF'
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../supabase_config.dart';

final authControllerProvider = StateNotifierProvider<AuthController, User?>(
  (ref) => AuthController(),
);

class AuthController extends StateNotifier<User?> {
  AuthController() : super(SupabaseConfig.client.auth.currentUser);

  Future<void> signIn(String email, String password) async {
    final response = await SupabaseConfig.client.auth.signInWithPassword(
      email: email,
      password: password,
    );
    state = response.user;
  }

  Future<void> signOut() async {
    await SupabaseConfig.client.auth.signOut();
    state = null;
  }
}
EOF

# Sign-in screen
cat > lib/features/auth/presentation/screens/sign_in_screen.dart << 'EOF'
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../controllers/auth_controller.dart';
import '../../../../shared/widgets/gradient_button.dart';

class SignInScreen extends ConsumerWidget {
  const SignInScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final emailController = TextEditingController();
    final passwordController = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text('Sign In')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: emailController, decoration: const InputDecoration(labelText: 'Email')),
            TextField(controller: passwordController, decoration: const InputDecoration(labelText: 'Password'), obscureText: true),
            const SizedBox(height: 20),
            GradientButton(
              text: "Sign In",
              onPressed: () {
                ref.read(authControllerProvider.notifier).signIn(
                      emailController.text,
                      passwordController.text,
                    );
              },
            )
          ],
        ),
      ),
    );
  }
}
EOF

# Auth Gateway
cat > lib/features/auth/presentation/screens/auth_gateway_screen.dart << 'EOF'
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../controllers/auth_controller.dart';
import 'package:go_router/go_router.dart';

class AuthGatewayScreen extends ConsumerWidget {
  const AuthGatewayScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authControllerProvider);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (user == null) {
        context.go('/signin');
      } else {
        // TODO: Navigate to dashboard
      }
    });

    return const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}
EOF

# Theme
cat > lib/core/theme/theme.dart << 'EOF'
import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.red),
      useMaterial3: true,
      scaffoldBackgroundColor: Colors.white,
    );
  }
}
EOF

# Gradient Button
cat > lib/shared/widgets/gradient_button.dart << 'EOF'
import 'package:flutter/material.dart';

class GradientButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;

  const GradientButton({super.key, required this.text, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      child: Text(text, style: const TextStyle(fontSize: 16)),
    );
  }
}
EOF

echo "✅ Folder structure and starter code created!"
