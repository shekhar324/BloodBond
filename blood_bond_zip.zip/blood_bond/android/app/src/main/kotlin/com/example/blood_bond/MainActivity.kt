package com.example.blood_bond

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
