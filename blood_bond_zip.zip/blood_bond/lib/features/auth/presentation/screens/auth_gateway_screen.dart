import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../controllers/auth_controller.dart';
import 'package:go_router/go_router.dart';

class AuthGatewayScreen extends ConsumerWidget {
  const AuthGatewayScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authControllerProvider);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (user == null) {
        context.go('/signin');
      } else {
        // TODO: Navigate to dashboard
      }
    });

    return const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}
