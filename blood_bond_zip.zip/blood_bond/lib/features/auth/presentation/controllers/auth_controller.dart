import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../supabase_config.dart';

final authControllerProvider = StateNotifierProvider<AuthController, User?>(
  (ref) => AuthController(),
);

class AuthController extends StateNotifier<User?> {
  AuthController() : super(SupabaseConfig.client.auth.currentUser);

  Future<void> signIn(String email, String password) async {
    final response = await SupabaseConfig.client.auth.signInWithPassword(
      email: email,
      password: password,
    );
    state = response.user;
  }

  Future<void> signOut() async {
    await SupabaseConfig.client.auth.signOut();
    state = null;
  }
}
